# -*- coding: utf-8 -*-
"""
Created on Fri Apr  9 14:20:10 2021

@author: 33699
"""

###PROJET IA KNN### 

#Importation des librairies
import pandas as pd 
import numpy as np
from math import *
from operator import itemgetter, attrgetter
from sklearn.metrics import accuracy_score


#DEFINITIONS DE FONCTIONS UTILES A L'ALGORITHME 
#FONCTION DISTANCE EUCLIDIENNE
#On a 6 classes, 6 variables d'entrée donc 6 points
def distanceEuclidienne(xA, yA, zA, tA, uA, vA, xB, yB, zB, tB,uB,vB) :
    distance=sqrt(((xB-xA)**2)+((yB-yA)**2)+((zB-zA)**2)+((tB-tA)**2)+((uB-uA)**2)+((vB-vA)**2))
    return distance

#FONCTION DE TRI
#Tri d'une liste
def quicksort(t):
    #cas d'une liste vide
    if t == []:
        return []
    else:
        #le pivot correspond au premier élément de la liste
        pivot = t[0]
        #Création de deux listes vides qui vont contenir les résultats
        t1 = []
        t2 = []
        #Puisque l'on met le pivot de côté, on parcourt la liste de 1 jusqu'à la fin
        for x in t[1:]:
            #Si l'élément comparé est plus petit que le pivot
            if x<pivot:
                #On l'ajoute à t1
                t1.append(x)
            #sinon à t2
            else:
                t2.append(x)
    #On regroupe les deux listes pour en faire qu'une
    return quicksort(t1)+[pivot]+quicksort(t2)

#ALGORITHME
#Chargement du dataset entrainement
dataEntrainement=pd.read_csv('finalEntrainement.csv', sep=',',header=None)
dataTest=pd.read_csv('finalTest.csv', sep=",", header=None)
#SMOTE pour ajuster les données
"""from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import LabelEncoder
from collections import Counter
X=dataEntrainement.iloc[:,0:6]
y=dataEntrainement.iloc[:,-1]
print('Before sampling', Counter(y))
y=LabelEncoder().fit_transform(y)
oversample=SMOTE()
X_sm,y_sm=oversample.fit_resample(X,y)
print('After sampling', Counter(y_sm))
smote_array = np.concatenate([X_sm, y_sm.reshape(-1, 1)], axis=1)
dataEntrainement=pd.DataFrame(smote_array, columns=dataEntrainement.columns)
for i in range(0,len(dataEntrainement)):
    if(dataEntrainement.iloc[i,6] ==0):
        dataEntrainement.iloc[i,6]='classA'
    elif(dataEntrainement.iloc[i,6]==1):
        dataEntrainement.iloc[i,6]='classB'
    elif(dataEntrainement.iloc[i,6]==2.0):
        dataEntrainement.iloc[i,6]='classC'
    elif(dataEntrainement.iloc[i,6]==3.0):
        dataEntrainement.iloc[i,6]='classD'
    elif(dataEntrainement.iloc[i,6]==4.0):
        dataEntrainement.iloc[i,6]='classE'"""


#On centre et on réduit le jeu de données
meanE0=dataEntrainement.mean()[0]
meanE1=dataEntrainement.mean()[1]
meanE2=dataEntrainement.mean()[2]
meanE3=dataEntrainement.mean()[3]
meanE4=dataEntrainement.mean()[4]
meanE5=dataEntrainement.mean()[5]
sdE0=dataEntrainement.std()[0]
sdE1=dataEntrainement.std()[1]
sdE2=dataEntrainement.std()[2]
sdE3=dataEntrainement.std()[3]
sdE4=dataEntrainement.std()[4]
sdE5=dataEntrainement.std()[5]
meanT0=dataTest.mean()[0]
meanT1=dataTest.mean()[1]
meanT2=dataTest.mean()[2]
meanT3=dataTest.mean()[3]
meanT4=dataTest.mean()[4]
meanT5=dataTest.mean()[5]
sdT0=dataTest.std()[0]
sdT1=dataTest.std()[1]
sdT2=dataTest.std()[2]
sdT3=dataTest.std()[3]
sdT4=dataTest.std()[4]
sdT5=dataTest.std()[5]

for i in range(0,len(dataEntrainement)):
    dataEntrainement.iloc[i,0]=(dataEntrainement.iloc[i,0]-meanE0)/sdE0
    dataEntrainement.iloc[i,1]=(dataEntrainement.iloc[i,1]-meanE1)/sdE1
    dataEntrainement.iloc[i,2]=(dataEntrainement.iloc[i,2]-meanE2)/sdE2
    dataEntrainement.iloc[i,3]=(dataEntrainement.iloc[i,3]-meanE3)/sdE3
    dataEntrainement.iloc[i,4]=(dataEntrainement.iloc[i,4]-meanE4)/sdE4
    dataEntrainement.iloc[i,5]=(dataEntrainement.iloc[i,5]-meanE5)/sdE5

for i in range(0,len(dataTest)):
    dataTest.iloc[i,0]=(dataTest.iloc[i,0]-meanT0)/sdT0
    dataTest.iloc[i,1]=(dataTest.iloc[i,1]-meanT1)/sdT1
    dataTest.iloc[i,2]=(dataTest.iloc[i,2]-meanT2)/sdT2
    dataTest.iloc[i,3]=(dataTest.iloc[i,3]-meanT3)/sdT3
    dataTest.iloc[i,4]=(dataTest.iloc[i,4]-meanT4)/sdT4
    dataTest.iloc[i,5]=(dataTest.iloc[i,5]-meanT5)/sdT5 
compteur=0
classification=[]
for i in range (0,len(dataTest)):
    #On s'intéresse à la ligne i dans le dataTest
    ligneTest=dataTest.iloc[i,0:6]
    #On calcule la différence de distance entre le point de la ligne étudiée et tous les points entraînements
    #création d'une liste qui contiendra toutes les différences de distance
    ensembleDistance=[]
    #création d'une liste qui contiendra tous les points correspondants aux distances
    ensemblePoint=[]
    #On parcourt chaque point du dataEntrainement
    for i in range(0,len(dataEntrainement)):
        #calcul de la distance euclidienne entre le point et la ligne i de l'entraînement
        distance=distanceEuclidienne(ligneTest[0], ligneTest[1], ligneTest[2], ligneTest[3],ligneTest[4],ligneTest[5], dataEntrainement.iloc[i,0], dataEntrainement.iloc[i,1], dataEntrainement.iloc[i,2], dataEntrainement.iloc[i,3],dataEntrainement.iloc[i,4],dataEntrainement.iloc[i,5])
        ensembleDistance.append(distance)
        ensemblePoint.append([distance, dataEntrainement.iloc[i,6]])
    #On trie les distances grâce au quicksort
    resDistance=quicksort(ensembleDistance)
    #On trie les points en fonction de la distance
    pointTrie=sorted(ensemblePoint, key=lambda ensemblePoint: ensemblePoint[0])
    #On garde seulement les k premiers éléments
    #k la racine de la longueur du dataset entraînement
    k=3
    del pointTrie[k:] 
    #On crée 5 compteur correspondant aux 5 classes
    a=0
    b=0
    c=0
    d=0
    e=0
    #On parcourt les points restants et on va retourner la catégorie dominante
    for i in range(0,len(pointTrie)):
        if(pointTrie[i][1]=='classA'):
            a=a+1
        if(pointTrie[i][1]=='classB'):
            b=b+1 
        if(pointTrie[i][1]=='classC'):
            c=c+1
        if(pointTrie[i][1]=='classD'):
            d=d+1 
        if(pointTrie[i][1]=='classE'):
            e=e+1 
    classeFinale=""
    if(a>b and a>c and a>d and a>e):
        classeFinale="classA"
    if(b>a and b>c and b>d and b>e):
        classeFinale="classB"
    if(c>b and c>a and c>d and c>e):
        classeFinale="classC"
    if(d>b and d>c and d>a and d>e):
        classeFinale="classD"
    if(e>a and e>c and e>d and e>a):
        classeFinale="classE"
    else:
        classeFinale=pointTrie[i][1]
    print(compteur,classeFinale)
    compteur=compteur+1
    classification.append(classeFinale)


#On écrit le résultat dans un fichier txt à côté
with open("classificationFinale.txt", "w") as outfile:
    outfile.write("\n".join(classification))



#Compter le nombre d'occurence de chaque classe
"""a=0
b=0
c=0
d=0
e=0
for i in range(0,len(dataEntrainement)):
    if(dataEntrainement.iloc[i,6]=='classA'):
        a+=1
    if(dataEntrainement.iloc[i,6]=='classB'):
        b+=1
    if(dataEntrainement.iloc[i,6]=='classC'):
        c+=1
    if(dataEntrainement.iloc[i,6]=='classD'):
        d+=1
    if(dataEntrainement.iloc[i,6]=='classE'):
        e+=1
print("a :",a)
print("b : ",b)
print("c : ",c)
print("d : ",d)
print("e : ",e) """ 



    














